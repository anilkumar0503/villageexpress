(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_web_0teg-6m._.js","static/chunks/node_modules_0_p_~nc._.js"],
    source: "dynamic"
});
