(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_web_08u.eg5._.js","static/chunks/node_modules_0dw7w6m._.js"],
    source: "dynamic"
});
