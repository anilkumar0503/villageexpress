(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_web_0qpenie._.js","static/chunks/node_modules_0dl0cwy._.js"],
    source: "dynamic"
});
