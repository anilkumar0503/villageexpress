(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_0qa0hi9._.js","static/chunks/apps_web_0l9-srs._.js"],
    source: "dynamic"
});
