(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0hnmvby._.js","static/chunks/apps_web_0~0a8qo._.js"],
    source: "dynamic"
});
