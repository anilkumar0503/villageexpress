(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__113f-2c._.css","static/chunks/0fuv_next_dist_0vpeyf9._.js"],
    source: "dynamic"
});
