(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/firebase/app/dist/esm/index.esm.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_0v281zz._.js",
  "static/chunks/node_modules_firebase_app_dist_esm_index_esm_04df.jt.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/firebase/app/dist/esm/index.esm.js [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/firebase/messaging/dist/esm/index.esm.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_0m98h1h._.js",
  "static/chunks/node_modules_firebase_messaging_dist_esm_index_esm_04df.jt.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/firebase/messaging/dist/esm/index.esm.js [app-client] (ecmascript)");
    });
});
}),
]);