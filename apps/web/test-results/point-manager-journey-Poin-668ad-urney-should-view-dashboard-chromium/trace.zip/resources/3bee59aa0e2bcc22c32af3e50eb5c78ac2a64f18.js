(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_firebase_0gayrk-._.js","static/chunks/_09xduaa._.js","static/chunks/apps_web_0eefe26._.js"],
    source: "dynamic"
});
