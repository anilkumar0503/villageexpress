(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_web_0g35fwa._.js","static/chunks/node_modules_0tc4fyc._.js"],
    source: "dynamic"
});
